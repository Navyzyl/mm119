num=0
for i in range(0,100):
    if i%2==0:
        num=num+i
    i = i + 1
print(num)